/* Copyright 2023 Miguel Gamboa
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. */

package aplicacion;

import java.util.ArrayList;
import java.util.List;

import com.jwetherell.algorithms.data_structures.Graph;
import com.jwetherell.algorithms.data_structures.Graph.Edge;
import com.jwetherell.algorithms.data_structures.Graph.Vertex;
import com.jwetherell.algorithms.graph.AStar;

public class Main {
    public static void main(String[] args) {
        // Creamos los vértices
        final List<Vertex<Integer>> vertices = new ArrayList<>();
        final Vertex<Integer> v1 = new Vertex<>(1);
        final Vertex<Integer> v2 = new Vertex<>(2);
        final Vertex<Integer> v3 = new Vertex<>(3);
        final Vertex<Integer> v4 = new Vertex<>(4);
        final Vertex<Integer> v5 = new Vertex<>(5);
        final Vertex<Integer> v6 = new Vertex<>(6);
        final Vertex<Integer> v7 = new Vertex<>(7);
        final Vertex<Integer> v8 = new Vertex<>(8);

        // Añadimos los vértices
        vertices.add(v1);
        vertices.add(v2);
        vertices.add(v3);
        vertices.add(v4);
        vertices.add(v5);
        vertices.add(v6);
        vertices.add(v7);
        vertices.add(v8);

        // Creamos las aristas
        final List<Edge<Integer>> edges = new ArrayList<>();
        final Edge<Integer> e1_2 = new Edge<>(7, v1, v2);
        final Edge<Integer> e1_3 = new Edge<>(9, v1, v3);
        final Edge<Integer> e1_6 = new Edge<>(14, v1, v6);
        final Edge<Integer> e2_3 = new Edge<>(10, v2, v3);
        final Edge<Integer> e2_4 = new Edge<>(15, v2, v4);
        final Edge<Integer> e3_4 = new Edge<>(11, v3, v4);
        final Edge<Integer> e3_6 = new Edge<>(2, v3, v6);
        final Edge<Integer> e6_5 = new Edge<>(9, v6, v5);
        final Edge<Integer> e6_8 = new Edge<>(14, v6, v8);
        final Edge<Integer> e4_5 = new Edge<>(6, v4, v5);
        final Edge<Integer> e4_7 = new Edge<>(16, v4, v7);
        final Edge<Integer> e1_8 = new Edge<>(30, v1, v8);

        // Añadimos las aristas
        edges.add(e1_2);
        edges.add(e1_3);
        edges.add(e1_6);
        edges.add(e2_3);
        edges.add(e2_4);
        edges.add(e3_4);
        edges.add(e3_6);
        edges.add(e6_5);
        edges.add(e6_8);
        edges.add(e4_5);
        edges.add(e4_7);
        edges.add(e1_8);

        // Creaamos el grafo con los vértices y aristas
        Graph<Integer> graph = new Graph<>(Graph.TYPE.DIRECTED, vertices, edges);

        // Resto del código para encontrar el camino con A*
        AStar<Integer> aStar = new AStar<>();
        
        //A continuación, haremos que el programa el camino desde v1 a v8. Podríamos elegir las vertices que queramos.
        List<Edge<Integer>> path = aStar.aStar(graph, v1, v8); 

        // Imprimir el camino encontrado
        if (path != null) {
        	System.out.println("Camino encontrado:");
		int totalCost = 0; // Variable para almacenar el costo total
		// Array para almacenar los costos de cada arista
		int[] valores = new int[path.size()];

		int i = 0;
		for (Edge<Integer> edge : path) {
		valores[i] = edge.getCost();
		totalCost += edge.getCost(); // Sumar el costo de esta arista al costo total
		System.out.println("Moverse del vértice " + edge.getFromVertex().getValue() + " al vértice " + edge.getToVertex().getValue() + " tiene un coste de " + valores[i]);
		i++;
	}

	System.out.println("\nEl coste total es: " + totalCost); // Imprimir el costo total
	}else {
		System.out.println("No se encontró un camino.");
	}

    }
}
